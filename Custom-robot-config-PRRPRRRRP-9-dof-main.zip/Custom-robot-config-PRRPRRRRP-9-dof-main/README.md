# Custom-robot-config-PRRPRRRRP 9 dof
assignment -RA2111002020012 
